# DISOMaster
A libisoburn wrapper class for Qt.

Dependencies:
 - \>= Qt 5.7
 - \>= libisoburn 1.2.6
 - Reasonable new C++ compiler with C++11 support

